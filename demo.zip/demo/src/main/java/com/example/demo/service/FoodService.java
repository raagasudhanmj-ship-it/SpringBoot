package com.example.demo.service;

import com.example.demo.model.Food;
import com.example.demo.repository.FoodRepository;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.Optional;

@Service
public class FoodService {

    private final FoodRepository foodRepository;

    public FoodService(FoodRepository foodRepository) {
        this.foodRepository = foodRepository;
    }

    public Collection<Food> findAll() {
        return foodRepository.findAll();
    }

    public Optional<Food> findById(int id) {
        return foodRepository.findById(id);
    }

    public Food create(Food food) {
        return foodRepository.save(food);
    }

    public Optional<Food> update(int id, Food food) {
        if (!foodRepository.existsById(id)) {
            return Optional.empty();
        }

        food.setId(id);
        return Optional.of(foodRepository.save(food));
    }

    public boolean delete(int id) {
        return foodRepository.deleteById(id);
    }
}
