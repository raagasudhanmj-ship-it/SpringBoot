package com.example.demo.repository;

import com.example.demo.model.Food;
import org.springframework.stereotype.Repository;

import java.util.Collection;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

@Repository
public class FoodRepository {

    private final ConcurrentHashMap<Integer, Food> foods = new ConcurrentHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    public Collection<Food> findAll() {
        return foods.values();
    }

    public Optional<Food> findById(int id) {
        return Optional.ofNullable(foods.get(id));
    }

    public Food save(Food food) {
        if (food.getId() == 0) {
            food.setId(nextId.getAndIncrement());
        }
        foods.put(food.getId(), food);
        return food;
    }

    public boolean existsById(int id) {
        return foods.containsKey(id);
    }

    public boolean deleteById(int id) {
        return foods.remove(id) != null;
    }
}
